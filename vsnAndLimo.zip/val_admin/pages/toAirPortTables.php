<?php
require('header.php');

require('sidebar.php');
?>


    <script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>
    
  
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.21/themes/redmond/jquery-ui.css" />






            

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script type="text/javascript" src="http://www.parsecdn.com/js/parse-1.3.2.min.js"></script>

 



        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">To Air Port</h1>





                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Vehicle type</th>
                                            <th>Total Passengers</th>
                                            <th>Selected luggage</th>
                                            <th>Optional Services</th>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>Pick up Address</th>
                                            <th>Drop off Address</th>
                                            <th>SpecialNotes</th>
                                            <th>Commute time</th>
                                            <th>Distance</th>
                                            <th>Fare</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                    </tbody>
                                </table>
                            </div> 

                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
        <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
            <script type="text/javascript" src="toAirPortTables.js"></script>

                <!-- Custom Theme JavaScript -->
                <script src="../dist/js/sb-admin-2.js"></script>
                 
            <script src="//www.parsecdn.com/js/parse-1.3.5.min.js"></script>

        <script src="assets/js/jquery-1.11.1.min.js" type="text/javascript"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Custom script -->
    <script src="assets/js/valscript.js" type="text/javascript"></script>

    </div>
    

</body>

</html>
